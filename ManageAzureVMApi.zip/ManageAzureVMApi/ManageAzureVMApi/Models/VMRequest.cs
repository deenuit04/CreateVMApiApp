﻿using System;
using System.Collections.Generic;


namespace ManageAzureVMApi.Models
{
    public class VMRequest
    {
        public string VMName { get; set; }
        public string VMLocation { get; set; }
        public string ResourceGroup { get; set; }
        public string VnetName { get; set; }
        public string SubnetName { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}