﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Threading.Tasks;
using Microsoft.Azure.Management.Compute.Fluent;
using Microsoft.Azure.Management.Compute.Fluent.Models;
using Microsoft.Azure.Management.Fluent;
using Microsoft.Azure.Management.ResourceManager.Fluent;
using Microsoft.Azure.Management.ResourceManager.Fluent.Core;
using ManageAzureVMApi.Models;



namespace ManageAzureVMApi.Controllers
{
    public class ManageVMController : ApiController
    {
        // GET: api/ManageVM
        public IEnumerable<string> Get()
        {
            return new string[] { "Hello", "VM" };
        }

        // GET: api/ManageVM/5
        public string Get(int id)
        {
            return "Hello";
        }

        // POST: api/ManageVM
        [EnableCors(origins: "https://fcvmapp.azurewebsites.net,https://angular-wrpr7z.stackblitz.io,http://localhost:57138", headers: "*", methods: "*")]
        public HttpResponseMessage Post([FromBody]VMRequest newVM)
        {
            try
            {
                //string strNewVMIP = DeployVM(newVM);
                return Request.CreateResponse<string>(HttpStatusCode.Created, string.Format("VM created successfully. IP: {0}", "198.162.0.1"));
            }
            catch (Exception ex)
            {
                return Request.CreateResponse<string>(HttpStatusCode.InternalServerError, ex.Message);
            }            
        }

        // PUT: api/ManageVM
        public void Put([FromBody]string value)
        {
            //DeployVM(value).Result;
        }

        // DELETE: api/ManageVM/5
        public void Delete(int id)
        {
        }

        private string DeployVM(VMRequest newVM)
        {
            var credentials = SdkContext.AzureCredentialsFactory.FromServicePrincipal(ConfigurationManager.AppSettings["clientId"], ConfigurationManager.AppSettings["clientSecret"], ConfigurationManager.AppSettings["tenantId"], AzureEnvironment.AzureGlobalCloud);
            var azure = Azure
                        .Configure()
                        .WithLogLevel(HttpLoggingDelegatingHandler.Level.Basic)
                        .Authenticate(credentials)
                        .WithDefaultSubscription();            
                        
            var publicIPAddress = azure.PublicIPAddresses.Define(ConfigurationManager.AppSettings["pulicIPName"])
                .WithRegion(newVM.VMLocation)
                .WithExistingResourceGroup(newVM.ResourceGroup)
                .WithDynamicIP()
                .Create();
                        
            var networkInterface = azure.NetworkInterfaces.Define(newVM.VMName)
                .WithRegion(newVM.VMLocation)
                .WithExistingResourceGroup(newVM.ResourceGroup)
                .WithExistingPrimaryNetwork(azure.Networks.GetByResourceGroup(newVM.ResourceGroup, newVM.VnetName))
                .WithSubnet(newVM.SubnetName)
                .WithPrimaryPrivateIPAddressDynamic()
                .WithExistingPrimaryPublicIPAddress(publicIPAddress)
                .Create();

            //Creating virtual machine..."
            azure.VirtualMachines.Define(newVM.VMName)
                .WithRegion(newVM.VMLocation)
                .WithExistingResourceGroup(newVM.ResourceGroup)
                .WithExistingPrimaryNetworkInterface(networkInterface)
                .WithLatestWindowsImage("MicrosoftWindowsServer", "WindowsServer", "2012-R2-Datacenter")
                .WithAdminUsername(newVM.UserName)
                .WithAdminPassword(newVM.Password)
                .WithComputerName(newVM.VMName)
                .WithSize(VirtualMachineSizeTypes.StandardDS1)
                .Create();

            return publicIPAddress.IPAddress;
        }

        /*
        private async Task<string> GetAccessToken()
        {
            string authContextUrl = "https://login.microsoftonline.com/" + System.Web.Configuration.WebConfigurationManager.AppSettings["tenantId"];
            string resourceUrl = "https://management.azure.com/";

            var authenticationContext = new AuthenticationContext(authContextUrl);
            var credential = new ClientCredential(System.Web.Configuration.WebConfigurationManager.AppSettings["clientId"], System.Web.Configuration.WebConfigurationManager.AppSettings["clientSecret"]);
            var result = await authenticationContext.AcquireTokenAsync(resourceUrl, credential);

            if (result == null)
            {
                throw new InvalidOperationException("Failed to obtain the JWT token");
            }

            string token = result.AccessToken;
            return token;
        }

        private async Task<string> DeployVM(string template)
        {
            string uriString = string.Format("https://management.azure.com/subscriptions/{0}/resourcegroups/{1}/providers/Microsoft.Resources/deployments/{2}?api-version=2019-05-01",
                                              System.Web.Configuration.WebConfigurationManager.AppSettings["subscriptionId"],
                                              System.Web.Configuration.WebConfigurationManager.AppSettings["resourceGroup"],
                                              System.Web.Configuration.WebConfigurationManager.AppSettings["deploymentName"]);
            Uri uri = new Uri(uriString);
            string token = await GetAccessToken();
            HttpClient httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Remove("Authorization");
            httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
            HttpResponseMessage response = await httpClient.PutAsJsonAsync(uri, template);
            return response.StatusCode.ToString();
        }
        */

    }
}
