﻿import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { VmrequestService } from '../vmrequest.service';
import {BroadcastService} from '@azure/msal-angular/dist';

@Component({
    selector: 'app-newvm',
    templateUrl: './newvm.component.html'
})
export class NewvmComponent implements OnInit {

    newvmForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;

    constructor(
        private formBuilder: FormBuilder,
        private vmRequest: VmrequestService,
        private broadcastService: BroadcastService
    ) {        
        // redirect to home if already logged in
        /*if (this.authenticationService.currentUserValue) {
            this.router.navigate(['/']);
        }*/
    }

    ngOnInit() {
        this.createForm();
        // get return url from route parameters or default to '/'
        //this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }

    createForm() {
        this.newvmForm = this.formBuilder.group({
            vmname: ['', Validators.required],
            vmlocation: ['', Validators.required],
            resourcegp: ['', Validators.required],
            vnetname: ['', Validators.required],
            subnetname: ['', Validators.required],
            username: ['', Validators.required],
            password: ['', Validators.required]
        });
    }
    // convenience getter for easy access to form fields
    get f() { return this.newvmForm.controls; }

    onClickSubmit(vmname, vmlocation, resourcegp, vnetname, subnetname, username, password) {

        this.broadcastService.subscribe("msal:acquireTokenSuccess", (payload) => {
            this.submitted = true;

            // stop here if form is invalid
            if (this.newvmForm.invalid) {
                return;
            }

            this.vmRequest.deployNewVM(vmname, vmlocation, resourcegp, vnetname, subnetname, username, password);
        });

        this.broadcastService.subscribe("msal:acquireTokenFailure", (payload) => {
            alert('Authentication failed:- Need to login first.');
        });
        
    }

}