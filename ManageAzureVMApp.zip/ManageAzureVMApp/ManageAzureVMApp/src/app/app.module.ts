import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppComponent } from './app.component';
import { NewvmComponent } from './newvm/newvm.component';
import { VmrequestService } from './vmrequest.service';
import { MsalModule, BroadcastService, MsalInterceptor} from '@azure/msal-angular/dist';

@NgModule({
  declarations: [
      AppComponent,
      NewvmComponent
  ],
  imports: [
      BrowserModule,
      AppRoutingModule,
      FormsModule,
      ReactiveFormsModule,
      HttpClientModule,
      MsalModule.forRoot({
          clientID: "857ca8af-e7f6-41b3-8a9a-19efec2d929b"
      })
  ],
  providers: [VmrequestService,
              BroadcastService,
              {
                provide: HTTP_INTERCEPTORS,
                useClass: MsalInterceptor,
                multi: true
              }
             ],
  bootstrap: [NewvmComponent]
})
export class AppModule { }
