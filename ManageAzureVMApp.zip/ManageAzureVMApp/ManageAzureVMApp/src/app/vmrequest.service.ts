﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class VmrequestService {

    constructor(private http: HttpClient) { }

    deployNewVM(vmname, vmlocation, resourcegp, vnetname, subnetname, username, password) {
        this.http.post("https://localhost:54846/api/ManageVM",
            {
                "VMName": vmname,
                "VMLocation": vmlocation,
                "ResourceGroup": resourcegp,
                "VnetName": vnetname,
                "SubnetName": subnetname,
                "UserName": username,
                "Password": password
            })
            .subscribe(
            data => {
                console.log("POST Request is successful ", data);
                alert('New VM was deployed with IP: ' + data);
            },
            error => {

                console.log("Error", error);
                alert('New VM deployment failed with Error: ' + error);
            }

            );
    }

}